.. parmap documentation master file, created by
   sphinx-quickstart on Mon Aug 31 00:11:46 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to parmap's documentation!
==================================

.. toctree::
   :maxdepth: 2


.. automodule:: parmap
   :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

