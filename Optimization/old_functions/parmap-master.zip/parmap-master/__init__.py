#!/usr/bin/env python
from parmap.parmap import map, starmap

__all__ = ['map', 'starmap']

